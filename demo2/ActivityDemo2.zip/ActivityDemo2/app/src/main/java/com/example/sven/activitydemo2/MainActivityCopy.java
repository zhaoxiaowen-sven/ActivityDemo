package com.example.sven.activitydemo2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class MainActivityCopy extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void startSecondCopy(View view){
        Intent intent = new Intent(this, SecondActivityCopy.class);
        startActivity(intent);
    }
}
